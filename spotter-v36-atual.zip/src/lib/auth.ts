// ============================================================
// XTACK SPOTTER — Autenticação real via Supabase
// Fallback para localStorage quando Supabase não está configurado
// ============================================================
import { supabase, SUPABASE_CONFIGURED } from "./supabase";

export interface AuthUser {
  id: string;
  email?: string;
  name?: string;
  profileType?: "personal" | "business" | null;
}

// Verifica se a PRÓPRIA conta (a sessão actual) foi suspensa pelo admin.
// Feito em segundo plano, depois do login já ter sido mostrado — nunca
// bloqueia a abertura da app (ver comentário grande em getCurrentUser()
// sobre porquê isso é importante em rede lenta). A política de RLS
// "Utilizador vê o seu perfil" já permite este SELECT sem precisar de
// nenhum privilégio extra — cada pessoa só lê a sua própria linha.
export async function isSelfSuspended(userId: string): Promise<boolean> {
  if (!SUPABASE_CONFIGURED || !supabase) return false;
  try {
    const { data, error } = await supabase
      .from("profiles")
      .select("suspended")
      .eq("id", userId)
      .maybeSingle();
    if (error || !data) return false;
    return Boolean(data.suspended);
  } catch {
    return false;
  }
}

// Busca o perfil pessoal já sincronizado em public.profiles (ver
// syncProfileToSupabase). Usado na recuperação de conta em home.tsx: se
// alguém entra numa conta já existente mas o draft local de onboarding
// não sabe disso (outro dispositivo, cache limpa, etc.), isto permite
// restaurar cidade/país/interesses sem obrigar a refazer o onboarding.
export interface RemoteProfile {
  name?: string;
  province?: string;
  city?: string;
  country?: string;
  favorite_category?: string;
}
export async function fetchProfile(userId: string): Promise<RemoteProfile | null> {
  if (!SUPABASE_CONFIGURED || !supabase) return null;
  try {
    const { data, error } = await supabase
      .from("profiles")
      .select("name, province, city, country, favorite_category")
      .eq("id", userId)
      .maybeSingle();
    if (error || !data || !data.city) return null;
    return data as RemoteProfile;
  } catch {
    return null;
  }
}

// ---------- helpers localStorage (fallback offline) ----------
// Guarda uma "base" de contas locais (simulação de utilizadores), não apenas
// a sessão activa, para que signIn possa validar a password correctamente
// em vez de aceitar qualquer combinação ou criar contas às escondidas.
const LOCAL_USER_KEY = "xlocal.auth.user.v1";
const LOCAL_ACCOUNTS_KEY = "xlocal.auth.accounts.v1";

interface LocalAccount {
  id: string;
  email: string;
  passwordHash: string;
  name?: string;
  profileType?: "personal" | "business" | null;
}

// Hash simples (não-criptográfico) só para o modo demo/offline.
// NUNCA usar isto como substituto de hashing real em produção —
// no modo Supabase a password nunca passa por aqui, é tratada pelo backend.
async function simpleHash(value: string): Promise<string> {
  const enc = new TextEncoder().encode(value);
  const buf = await crypto.subtle.digest("SHA-256", enc);
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

function localGetSessionUser(): AuthUser | null {
  try {
    const raw = localStorage.getItem(LOCAL_USER_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}
function localSetSessionUser(u: AuthUser | null) {
  try {
    if (u) localStorage.setItem(LOCAL_USER_KEY, JSON.stringify(u));
    else localStorage.removeItem(LOCAL_USER_KEY);
  } catch {
    /* ignorado: falha de quota/acesso ao localStorage */
  }
}
function localGetAccounts(): LocalAccount[] {
  try {
    const raw = localStorage.getItem(LOCAL_ACCOUNTS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}
function localSaveAccounts(accounts: LocalAccount[]) {
  try {
    localStorage.setItem(LOCAL_ACCOUNTS_KEY, JSON.stringify(accounts));
  } catch {
    /* ignorado: falha de quota/acesso ao localStorage */
  }
}
function localFindAccountByEmail(email: string): LocalAccount | undefined {
  const normalized = email.trim().toLowerCase();
  return localGetAccounts().find((a) => a.email.toLowerCase() === normalized);
}

// Sincroniza nome, cidade e categoria de interesse preferida (escolhidos
// no onboarding, que vive em localStorage) para a tabela public.profiles.
// Sem isto, o nome/cidade do utilizador NUNCA chegam ao Supabase — e as
// notificações automáticas personalizadas ("Olá {nome}, queres visitar
// {local}?"), que são geradas no servidor por uma Edge Function sem
// acesso a localStorage de ninguém, não teriam como saber o nome ou a
// cidade de quem vai receber a notificação.
// Falha em silêncio (best-effort): nunca deve impedir o onboarding de
// avançar só porque a sincronização de perfil falhou.
export async function syncProfileToSupabase(patch: {
  name?: string;
  province?: string;
  city?: string;
  country?: string;
  favoriteCategory?: string;
}): Promise<void> {
  if (!SUPABASE_CONFIGURED || !supabase) return;
  try {
    const { data } = await supabase.auth.getSession();
    const userId = data.session?.user?.id;
    if (!userId) return; // utilizador "convidado" sem conta — nada a sincronizar
    await supabase
      .from("profiles")
      .update({
        ...(patch.name !== undefined ? { name: patch.name } : {}),
        ...(patch.province !== undefined ? { province: patch.province } : {}),
        ...(patch.city !== undefined ? { city: patch.city } : {}),
        ...(patch.country !== undefined ? { country: patch.country } : {}),
        ...(patch.favoriteCategory !== undefined
          ? { favorite_category: patch.favoriteCategory }
          : {}),
      })
      .eq("id", userId);
  } catch (err) {
    console.warn("syncProfileToSupabase: falha ao sincronizar perfil.", err);
  }
}

// Persistir o tipo de perfil (pessoal/comercial) também junto à conta,
// não apenas no draft de onboarding em localStorage solto — assim o
// tipo de conta sobrevive mesmo limpando o draft de onboarding.
export async function setProfileType(
  userId: string,
  profileType: "personal" | "business",
): Promise<void> {
  if (SUPABASE_CONFIGURED && supabase) {
    try {
      await supabase.auth.updateUser({ data: { profileType } });
    } catch (err) {
      console.warn("setProfileType: Supabase indisponível, guardado apenas localmente.", err);
    }
  }
  const accounts = localGetAccounts();
  const idx = accounts.findIndex((a) => a.id === userId);
  if (idx >= 0) {
    accounts[idx] = { ...accounts[idx], profileType };
    localSaveAccounts(accounts);
  }
  const session = localGetSessionUser();
  if (session && session.id === userId) {
    localSetSessionUser({ ...session, profileType });
  }
}

// ---------- Sign Up ----------
// ---------- Traduzir erros técnicos do Supabase para português claro ----------
// BUG DO ABRÃO (2026-08-23): "não aceitava clicar colocar um email", e
// contas criadas com Google presas ao tentar entrar. Causa real: o
// supabase-js NÃO lança excepção em falhas de rede — devolve
// { error: { message: "Failed to fetch" } } (texto em inglês, da própria
// API fetch do browser) como um erro NORMAL, que o código antigo
// mostrava tal e qual na tela. Numa ligação móvel instável (comum em
// Moçambique), isto aparecia como "Failed to fetch" sem tradução — dava
// a impressão de que o formulário "não aceitava" o email, quando na
// verdade era só a internet a falhar naquele instante. O mesmo
// acontecia com "User already registered" (alguém que já tem conta,
// ex: criada com Google, tentando "Criar conta" de novo com o mesmo
// email) — em inglês, sem indicar que devia era usar o botão Google.
function translateAuthError(raw: string): string {
  const msg = raw.toLowerCase();
  if (
    msg.includes("failed to fetch") ||
    msg.includes("network") ||
    msg.includes("load failed") ||
    msg.includes("fetch failed")
  ) {
    return "Sem ligação à internet neste momento. Verifica a tua ligação e tenta novamente.";
  }
  if (
    msg.includes("already registered") ||
    msg.includes("already exists") ||
    msg.includes("user_repeated_signup")
  ) {
    return 'Já existe uma conta com este email. Toca em "Já tem conta? Entrar" — se criaste a conta com Google, usa o botão "Continuar com Google".';
  }
  if (msg.includes("email not confirmed")) {
    return "Confirma o teu email antes de entrar — verifica a caixa de entrada (e o spam).";
  }
  if (msg.includes("invalid login credentials") || msg.includes("invalid_credentials")) {
    return "Email ou senha incorrectos.";
  }
  if (msg.includes("password") && msg.includes("6")) {
    return "A senha precisa de pelo menos 6 caracteres.";
  }
  return raw; // erro específico do Supabase que já vem claro — mostra tal como está
}

export async function signUp(
  email: string,
  password: string,
  name?: string,
): Promise<{ user: AuthUser | null; error: string | null; needsEmailConfirmation?: boolean }> {
  if (SUPABASE_CONFIGURED && supabase) {
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: { data: { name }, emailRedirectTo: `${window.location.origin}/` },
      });
      if (error) return { user: null, error: translateAuthError(error.message) };
      if (!data.user) return { user: null, error: "Erro ao criar conta" };
      // CORREÇÃO (pedido do Abrão, 2026-09-22): quando "Confirm email" está
      // ligado no Supabase, signUp() devolve data.user preenchido mas
      // data.session vazio — a conta existe, mas ainda não pode ser usada
      // até a pessoa clicar no link enviado por email. Antes, este código
      // ignorava isso e devolvia como se já estivesse tudo pronto, o que
      // empurrava a pessoa para o onboarding sem sessão real por trás
      // (falhas silenciosas mais à frente, sem explicação). Agora sinaliza
      // isso separadamente, para o ecrã mostrar "confirma o teu email" em
      // vez de avançar. Quando "Confirm email" está desligado (como está
      // hoje), data.session já vem preenchido e nada muda no fluxo actual.
      if (!data.session) {
        return { user: null, error: null, needsEmailConfirmation: true };
      }
      const u: AuthUser = {
        id: data.user.id,
        email: data.user.email,
        name,
        profileType: data.user.user_metadata?.profileType ?? null,
      };
      return { user: u, error: null };
    } catch (err) {
      console.warn("signUp: falha de rede ao contactar Supabase.", err);
      return {
        user: null,
        error: "Sem ligação à internet. Verifique a sua ligação e tente novamente.",
      };
    }
  }
  // Fallback offline: valida que o email ainda não existe
  const normalized = email.trim().toLowerCase();
  if (!normalized || !password || password.length < 6) {
    return { user: null, error: "Email inválido ou senha com menos de 6 caracteres" };
  }
  const existing = localFindAccountByEmail(normalized);
  if (existing) {
    return { user: null, error: "Já existe uma conta com este email. Tente entrar." };
  }
  const passwordHash = await simpleHash(password);
  const account: LocalAccount = {
    id: crypto.randomUUID(),
    email: normalized,
    passwordHash,
    name,
    profileType: null,
  };
  localSaveAccounts([...localGetAccounts(), account]);
  const u: AuthUser = {
    id: account.id,
    email: account.email,
    name: account.name,
    profileType: null,
  };
  localSetSessionUser(u);
  return { user: u, error: null };
}

// ---------- Sign In ----------
export async function signIn(
  email: string,
  password: string,
): Promise<{ user: AuthUser | null; error: string | null }> {
  if (SUPABASE_CONFIGURED && supabase) {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });
      // BUG DO ABRÃO (2026-08-23): antes, QUALQUER erro aqui (incluindo
      // falha de rede pura) mostrava sempre "Email ou senha incorrectos"
      // — alguém sem sinal por um instante era enganado a pensar que
      // se tinha esquecido da senha. Agora distingue rede de
      // credenciais erradas.
      if (error) return { user: null, error: translateAuthError(error.message) };
      if (!data.user) return { user: null, error: "Erro ao entrar" };
      const u: AuthUser = {
        id: data.user.id,
        email: data.user.email,
        name: data.user.user_metadata?.name,
        profileType: data.user.user_metadata?.profileType ?? null,
      };
      return { user: u, error: null };
    } catch (err) {
      console.warn("signIn: falha de rede ao contactar Supabase.", err);
      return {
        user: null,
        error: "Sem ligação à internet. Verifique a sua ligação e tente novamente.",
      };
    }
  }
  // Fallback offline: agora valida mesmo a password e NUNCA cria conta nova aqui.
  const normalized = email.trim().toLowerCase();
  const account = localFindAccountByEmail(normalized);
  if (!account) {
    return { user: null, error: "Não existe conta com este email. Crie uma conta primeiro." };
  }
  const passwordHash = await simpleHash(password);
  if (account.passwordHash !== passwordHash) {
    return { user: null, error: "Email ou senha incorrectos" };
  }
  const u: AuthUser = {
    id: account.id,
    email: account.email,
    name: account.name,
    profileType: account.profileType ?? null,
  };
  localSetSessionUser(u);
  return { user: u, error: null };
}

// ---------- Sign In com Google / Apple (OAuth) ----------
// Requer que o provider correspondente esteja activado em
// Supabase Dashboard → Authentication → Providers, com o Client ID/Secret
// da Google Cloud Console ou Apple Developer respectivamente.
// Sem Supabase configurado, não há OAuth real possível (não existe
// servidor próprio a tratar disto) — cai num erro claro em vez de fingir
// que entrou, para não confundir "pareceu funcionar" com "entrou mesmo".
export async function signInWithOAuth(
  provider: "google" | "apple",
): Promise<{ error: string | null }> {
  if (!SUPABASE_CONFIGURED || !supabase) {
    return {
      error:
        "Login com " +
        (provider === "google" ? "Google" : "Apple") +
        " requer o Supabase configurado.",
    };
  }
  try {
    // redirectTo aponta de volta para a própria app (raiz). O Supabase
    // devolve o utilizador com a sessão já incluída na URL
    // (detectSessionInUrl: true trata disto automaticamente em main.tsx),
    // e o useAuth() existente apanha a sessão via onAuthStateChange.
    const { error } = await supabase.auth.signInWithOAuth({
      provider,
      options: {
        redirectTo: `${window.location.origin}/`,
        // BUG DO ABRÃO (2026-08-19): "tentei sair e iniciar sessão com
        // outra conta, não aceitou... volta à conta antiga". Sem isto,
        // se o telemóvel já tinha uma sessão Google aberta, o Google
        // reentrava automaticamente nessa MESMA conta, sem sequer
        // mostrar a lista de contas — parecia que a app estava "presa"
        // na conta antiga, mas era o próprio Google a pular a escolha.
        // Isto força sempre a lista de contas a aparecer.
        queryParams: provider === "google" ? { prompt: "select_account" } : undefined,
      },
    });
    if (error) return { error: translateAuthError(error.message) };
    // Em sucesso o browser é redireccionado para o provider — não há mais
    // nada a devolver aqui; o fluxo continua noutra navegação da página.
    return { error: null };
  } catch (err) {
    console.warn(`signInWithOAuth(${provider}): falha de rede.`, err);
    return { error: "Sem ligação à internet. Verifique a sua ligação e tente novamente." };
  }
}

// ---------- Sign Out ----------
export async function signOut(): Promise<void> {
  if (SUPABASE_CONFIGURED && supabase) {
    try {
      await supabase.auth.signOut();
    } catch (err) {
      console.warn(
        "signOut: falha ao contactar Supabase, a terminar sessão apenas localmente.",
        err,
      );
    }
  }
  localSetSessionUser(null);
}

// Pedido do Abrão (2026-09-09): apagar a própria conta, de vez.
// Não dá para fazer isto directamente do browser — apagar um utilizador
// do Supabase Auth exige a service_role key, que nunca pode estar no
// código do cliente (dá acesso total à base de dados, ignorando RLS).
// Por isso isto só invoca a Edge Function delete-own-account, que corre
// no servidor com essa key — ver supabase/functions/delete-own-account.
// Devolve { error } (string) em caso de falha, ou {} em caso de sucesso.
export async function deleteOwnAccount(): Promise<{ error?: string }> {
  if (!SUPABASE_CONFIGURED || !supabase) {
    return { error: "Supabase não está configurado." };
  }
  try {
    const { error } = await supabase.functions.invoke("delete-own-account");
    if (error) {
      console.warn("deleteOwnAccount: falha na Edge Function.", error);
      return { error: "Não foi possível apagar a conta. Tenta novamente mais tarde." };
    }
    localSetSessionUser(null);
    return {};
  } catch (err) {
    console.warn("deleteOwnAccount: erro inesperado.", err);
    return { error: "Não foi possível apagar a conta. Tenta novamente mais tarde." };
  }
}

// ---------- Get current user ----------
// CRÍTICO: usa getSession() em vez de getUser().
// getUser() faz SEMPRE uma chamada de rede para validar o token contra o
// servidor Supabase. Na abertura da app (sobretudo no APK, com rede lenta
// ou ainda a estabelecer ligação), essa chamada pode demorar, falhar por
// timeout, ou correr antes do token de refresh estar disponível — e cada
// uma dessas situações fazia cair no catch, devolvendo `null` e expulsando
// o utilizador para o login mesmo com uma sessão válida guardada.
// getSession() lê a sessão directamente do storage local (instantâneo, sem
// rede) e é a forma recomendada pelo Supabase para saber "há sessão?" no
// arranque da app. A validação/renovação do token continua a acontecer em
// segundo plano via onAuthStateChange (evento TOKEN_REFRESHED), sem nunca
// bloquear nem derrubar a sessão visível ao utilizador.
export async function getCurrentUser(): Promise<AuthUser | null> {
  if (SUPABASE_CONFIGURED && supabase) {
    try {
      const { data, error } = await supabase.auth.getSession();
      if (error) {
        console.warn("getCurrentUser: erro ao ler sessão local, a usar fallback.", error);
        return localGetSessionUser();
      }
      const su = data.session?.user;
      if (su) {
        const u: AuthUser = {
          id: su.id,
          email: su.email,
          name: su.user_metadata?.name,
          profileType: su.user_metadata?.profileType ?? null,
        };
        // mantém a sessão local sincronizada para que, mesmo que uma
        // próxima leitura do storage do Supabase falhe momentaneamente,
        // ainda exista uma cópia local válida e recente.
        localSetSessionUser(u);
        return u;
      }
      // Sem sessão no Supabase: ainda assim verifica se existe uma sessão
      // local recente antes de assumir "deslogado" — protege contra uma
      // leitura de storage que ainda não tenha sido hidratada a tempo.
      return localGetSessionUser();
    } catch (err) {
      console.warn("getCurrentUser: Supabase indisponível, a usar sessão local.", err);
      return localGetSessionUser();
    }
  }
  return localGetSessionUser();
}

// ---------- Listen to auth changes ----------
// Escuta TODOS os eventos relevantes do Supabase, incluindo:
// - INITIAL_SESSION: disparado uma vez ao arrancar, depois de o SDK ler o storage
// - TOKEN_REFRESHED: disparado em segundo plano quando o token é renovado
// - SIGNED_IN / SIGNED_OUT: ações explícitas do utilizador
// Em qualquer evento com sessão válida, a cópia local é actualizada — é isto
// que garante que localGetSessionUser() nunca fica "desactualizado" em
// relação ao que o Supabase realmente tem guardado.
export function onAuthChange(callback: (user: AuthUser | null) => void) {
  if (SUPABASE_CONFIGURED && supabase) {
    const { data } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        const u: AuthUser = {
          id: session.user.id,
          email: session.user.email,
          name: session.user.user_metadata?.name,
          profileType: session.user.user_metadata?.profileType ?? null,
        };
        localSetSessionUser(u);
        callback(u);
      } else {
        localSetSessionUser(null);
        callback(null);
      }
    });
    return () => data.subscription.unsubscribe();
  }
  return () => {};
}

// ============================================================
// Recuperação de senha ("Esqueci a senha")
// ------------------------------------------------------------
// Pedido do Abrão (2026-09-22): esta funcionalidade não existia —
// quem esquecesse a senha ficava sem hipótese de recuperar a conta.
// Fluxo: pede o email → Supabase manda um link → a pessoa toca no
// link → volta para /reset-password já com uma sessão temporária de
// recuperação (o Supabase trata isso sozinho, via URL) → escreve a
// senha nova → updateUser().
// ============================================================

// Sem domínio próprio ainda: usa sempre window.location.origin, que
// aponta para onde a app está a correr no momento (localhost em
// desenvolvimento, o domínio .vercel.app depois de publicado, ou um
// domínio próprio no futuro) — não precisa de nada fixo no código.
// Mesmo padrão já usado em signInWithOAuth() acima.
export async function sendPasswordReset(email: string): Promise<{ error: string | null }> {
  if (!SUPABASE_CONFIGURED || !supabase) {
    return { error: "Recuperação de senha só está disponível com o Supabase ligado." };
  }
  try {
    const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    if (error) return { error: translateAuthError(error.message) };
    return { error: null };
  } catch (err) {
    console.warn("sendPasswordReset: falha de rede ao contactar Supabase.", err);
    return { error: "Sem ligação à internet. Verifique a sua ligação e tente novamente." };
  }
}

// Chamado na página /reset-password, depois de a pessoa ter clicado no
// link do email — a essa altura já existe uma sessão temporária de
// recuperação (o Supabase estabelece-a sozinho ao abrir o link), por
// isso updateUser() já basta, sem pedir a senha antiga.
export async function updatePasswordAfterReset(
  newPassword: string,
): Promise<{ error: string | null }> {
  if (!SUPABASE_CONFIGURED || !supabase) {
    return { error: "Recuperação de senha só está disponível com o Supabase ligado." };
  }
  try {
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    if (error) return { error: translateAuthError(error.message) };
    return { error: null };
  } catch (err) {
    console.warn("updatePasswordAfterReset: falha de rede ao contactar Supabase.", err);
    return { error: "Sem ligação à internet. Verifique a sua ligação e tente novamente." };
  }
}

// Reenvia o email de confirmação de conta (usado quando "Confirm
// email" está ligado no Supabase e a pessoa não recebeu ou perdeu o
// primeiro email, enviado automaticamente em signUp()).
export async function resendConfirmationEmail(email: string): Promise<{ error: string | null }> {
  if (!SUPABASE_CONFIGURED || !supabase) {
    return { error: "Confirmação de email só está disponível com o Supabase ligado." };
  }
  try {
    const { error } = await supabase.auth.resend({
      type: "signup",
      email: email.trim(),
      options: { emailRedirectTo: `${window.location.origin}/` },
    });
    if (error) return { error: translateAuthError(error.message) };
    return { error: null };
  } catch (err) {
    console.warn("resendConfirmationEmail: falha de rede ao contactar Supabase.", err);
    return { error: "Sem ligação à internet. Verifique a sua ligação e tente novamente." };
  }
}
